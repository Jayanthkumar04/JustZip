/**
 * 
 */
/**
 * 
 */
module Strings {
}