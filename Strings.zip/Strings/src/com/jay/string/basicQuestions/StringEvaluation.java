package com.jay.string.basicQuestions;

public class StringEvaluation {

	public static void main(String[] args) {

		//evaluates from left to right  --->----->----->
		
		System.out.println("abc"+10+20);
		
		
		System.out.println(10+20+"abc");
		
		
	}

}
