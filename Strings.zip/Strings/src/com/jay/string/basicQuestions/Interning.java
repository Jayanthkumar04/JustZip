package com.jay.string.basicQuestions;

public class Interning {

	public static void main(String[] args) {

		String s1 = "abc";
		
		String s2 = "abc";
		
		System.out.println(s1 == s2); //checks for address(memory location
	
	    System.out.println(s1.equals(s2));
		
	    String s3 = new String("abc");
	    
	    System.out.println(s2 == s3); //now diff memory location so false
	    
	    
	    
	}

}
