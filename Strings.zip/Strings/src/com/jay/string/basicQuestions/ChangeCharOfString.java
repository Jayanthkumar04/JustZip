package com.jay.string.basicQuestions;

public class ChangeCharOfString {

	public static void changeChar(String str)
	{
		//changing 3rd character (L) to (y)
		str = str.substring(0,2)+'y'+str.substring(3);
		
		System.out.println(str);
	}
	
	public static void evenPositionsTOA(String str)
	{
		String ans="";
		for(int i=0;i<str.length();i++)
		{
			if(i % 2 == 0)
			{
				ans = ans+'a';
			}
			else {
				ans=ans+str.charAt(i);
			}
		}
		
		System.out.println(ans);
	}
	
	public static void main(String[] args) {

		String str = "hello";
		
		changeChar(str);
		
		evenPositionsTOA(str);
		
	
		
	}

}
