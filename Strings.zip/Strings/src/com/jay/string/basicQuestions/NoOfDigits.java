package com.jay.string.basicQuestions;

public class NoOfDigits {

	
	public static void countNoOfDigits(int number)
	{
		String count ="";
		count = count+number;
		
		System.out.println("no.of.digits == "+count.length());
	}
	public static void main(String[] args) {

		int number = 10023;
		
		countNoOfDigits(number);
		
		
	}

}
