package com.jay.string.StringbuilderBuffer;

public class StringBuilderr {

	public static void main(String[] args) {

		StringBuilder sb = new StringBuilder("jayanth");
		
		System.out.println(sb.reverse());
		
		System.out.println(sb.capacity());
		
		sb.setCharAt(0, 'C');
		
		System.out.println(sb);
	
		
		
	
	}

}
