package com.jay.string.basics;

public class StringDeclaring {

	public static void main(String[] args) {

		String s1 = "jayanth";
		
		String s2 = "jayanth";
		
		System.out.println(s1 == s2);
		
	    String s3 = "jayant";
	    
	    System.out.println(s1 == s3);
	    
	    String s4 = new String("jayanth");
	    
	    System.out.println(s1 == s4);
	    
	    
	    
	    
	}

}
