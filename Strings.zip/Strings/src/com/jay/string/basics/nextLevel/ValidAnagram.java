package com.jay.string.basics.nextLevel;

import java.util.Arrays;

public class ValidAnagram {

	public static void main(String[] args) {

		String s1 = "anagrams";
		String s2 = "nagaramn";
		
		char ans1[] = s1.toCharArray();
		
		char ans2[] = s2.toCharArray();
		
		Arrays.sort(ans1);
		Arrays.sort(ans2);
		boolean ans = true;
		for(int i=0;i<ans1.length;i++)
		{
			if(ans1[i] != ans2[i]) 
			{
			   ans = false;
				break;
			
			}
			
		}
		
		if(ans == false) System.out.println("it is not an anagram");
		else System.out.println("anagram");
		
	}

}
