package com.jay.string.basics.nextLevel;

public class ReverseEachWordInSentence {

	public static void reverse(StringBuilder s,int i,int j)
	{
		while(i<j)
		{
			char temp = s.charAt(i);
			s.setCharAt(i, s.charAt(j));
			s.setCharAt(j, temp);
			i++;
			j--;
		}
	}
	public static void reverseSentence(StringBuilder s)
	{
		int i=0,j=0;
		
		while(j<s.length())
		{
			if(s.charAt(j) != ' ') j++;
			else
			{
				reverse(s,i,j-1);
				i=j+1;
				j=i;
			}
		}
		
		reverse(s,i,j-1);
		
	}
	public static void main(String args[])
	{
		
		StringBuilder s = new StringBuilder("this is business");
		
	    reverseSentence(s);
	    
	    System.out.println(s);
	}
}
