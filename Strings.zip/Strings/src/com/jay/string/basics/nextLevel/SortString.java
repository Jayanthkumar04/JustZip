package com.jay.string.basics.nextLevel;

import java.util.Arrays;

public class SortString {

	public static void main(String[] args) {

		String s = "jaya";
		
		char ch[] = s.toCharArray();
		
		Arrays.sort(ch);
		
		System.out.println(new String(ch));
	}

}
