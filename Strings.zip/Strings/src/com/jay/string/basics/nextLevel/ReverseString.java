package com.jay.string.basics.nextLevel;

public class ReverseString {

	public static String reverseWord(String s)
	{
		
		char ch[] = s.toCharArray();
		
		int i=0,j=ch.length-1;
		
		while(i < j)
		{
			char temp = ch[i];
			
			ch[i] = ch[j];
			
			ch[j] = temp;
			i++;
			j--;
		}
		
		return new String(ch);
		
		
	}
	public static void main(String[] args) {

		String s = "boy";
		
		String ans = reverseWord(s);
		
		System.out.println(ans);
		
	}

}
