package com.jay.string.basics;

public class OtherMethods {

	public static void main(String[] args) {

		String s1 = "jayanth kumar";
		
		System.out.println(s1.contains("a"));
		
		System.out.println(s1.startsWith("jay"));
		
		System.out.println(s1.endsWith("mr"));
		
		s1.toLowerCase();
		
		s1.toUpperCase();
		
		s1.compareTo("jay");//0 ,lexigrophical order 
		
		System.out.println(s1.concat("abc"));
		
		
	}

}
