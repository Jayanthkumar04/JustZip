package com.jobboard;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JobBoardLiteeApplication {

	public static void main(String[] args) {
		SpringApplication.run(JobBoardLiteeApplication.class, args);
	}

}
