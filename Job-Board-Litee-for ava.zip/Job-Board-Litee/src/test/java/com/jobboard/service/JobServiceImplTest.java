package com.jobboard.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import com.jobboard.dvo.Job;
import com.jobboard.exceptions.EntityNotFoundException;
import com.jobboard.repo.JobRepo;

@ExtendWith(MockitoExtension.class)
public class JobServiceImplTest {

	@Mock
	private JobRepo jobRepo;

	@InjectMocks
	private JobServiceImpl jobService;

	@Test
	public void getAllJobs_shouldReturnListOfJobs() {
		List<Job> jobs = Arrays.asList(new Job(), new Job());
		when(jobRepo.findAll()).thenReturn(jobs);

		List<Job> result = jobService.getAllJobs();

		assertEquals(2, result.size());
		verify(jobRepo, times(1)).findAll();
	}

	@Test
    public void getAllJobs_shouldReturnEmptyList() {
        when(jobRepo.findAll()).thenReturn(Collections.emptyList());

        List<Job> result = jobService.getAllJobs();

        assertTrue(result.isEmpty());
        verify(jobRepo, times(1)).findAll();
    }

	@Test
	public void getJobById_shouldReturnJob_whenIdExists() {
		Job job = new Job();
		when(jobRepo.findById(1L)).thenReturn(Optional.of(job));

		Job result = jobService.getJobById(1L);

		assertNotNull(result);
		verify(jobRepo, times(1)).findById(1L);
	}

	@Test
    public void getJobById_shouldThrowException_whenIdNotFound() {
        when(jobRepo.findById(99L)).thenReturn(Optional.empty());

        EntityNotFoundException ex = assertThrows(EntityNotFoundException.class, () -> jobService.getJobById(99L));
        assertEquals("job id with 99 is not found", ex.getMessage());
        verify(jobRepo, times(1)).findById(99L);
    }

	@Test
	public void getJobsBySearch_shouldReturnJobs_whenFound() {
		List<Job> jobs = Arrays.asList(new Job());
		when(jobRepo.findByTitle("dev")).thenReturn(jobs);

		List<Job> result = jobService.getJobsBySearch("dev");

		assertEquals(1, result.size());
		verify(jobRepo, times(1)).findByTitle("dev");
	}

	@Test
    public void getJobsBySearch_shouldThrowException_whenNotFound() {
        when(jobRepo.findByTitle("zzz")).thenReturn(null);

        EntityNotFoundException ex = assertThrows(EntityNotFoundException.class, () -> jobService.getJobsBySearch("zzz"));
        assertEquals("Job with title zzz is not found", ex.getMessage());
        verify(jobRepo, times(1)).findByTitle("zzz");
    }

	@Test
	public void getJobsByLocation_shouldReturnJobs_whenFound() {
		List<Job> jobs = Arrays.asList(new Job());
		when(jobRepo.findByLocation("NY")).thenReturn(jobs);

		List<Job> result = jobService.getJobsByLocation("NY");

		assertEquals(1, result.size());
		verify(jobRepo, times(1)).findByLocation("NY");
	}

	@Test
    public void getJobsByLocation_shouldThrowException_whenNotFound() {
        when(jobRepo.findByLocation("Moon")).thenReturn(null);

        EntityNotFoundException ex = assertThrows(EntityNotFoundException.class, () -> jobService.getJobsByLocation("Moon"));
        assertEquals("Job in location Moon is not found", ex.getMessage());
        verify(jobRepo, times(1)).findByLocation("Moon");
    }

	@Test
	public void addJob_shouldReturnSavedJob() {
		Job job = new Job();
		when(jobRepo.save(job)).thenReturn(job);

		Job result = jobService.addJob(job);

		assertNotNull(result);
		verify(jobRepo, times(1)).save(job);
	}
}
